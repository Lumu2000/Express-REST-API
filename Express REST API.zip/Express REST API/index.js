const express = require('express');
const path = require('path');


const app = express();

// app.get('/', (req, res) =>{
// res.sendFile(path.join(__dirname, 'public', 'index.html'))

// });


//Init Body Parser
app.use(express.json());
app.use(express.urlencoded({extended: false}))

//Set  a static Folder
app.use(express.static(path.join(__dirname, 'public')));

//In order to use the routes // MEMBERS API ROUTES
app.use('/api/members/', require('./routes/api/members'))


const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log('server running on port ${PORT}'));

const members = [
    {
        id: 1,
        name: 'John Doe',
        email: 'johndoe@gmail.com',
        status: 'active'
    },
    {
        id: 2,
        name: 'John',
        email: 'johndoe@gmail.com',
        status: 'inactive'
    },
    {
        id: 3,
        name: 'Doe',
        email: 'johndoe@gmail.com',
        status: 'inactive'
    }

]


module.exports = members